import gradio as gr
from transformers import pipeline

# Load summarization pipeline
summarizer = pipeline("summarization")

# Function to summarize educational content
def summarize_text(text):
    summary = summarizer(text, max_length=100, min_length=30, do_sample=False)
    return summary[0]['summary_text']

# Gradio interface
demo = gr.Interface(
    fn=summarize_text,
    inputs=gr.Textbox(lines=10, label="📚 Enter Educational Text"),
    outputs=gr.Textbox(label="✂️ Summary"),
    title="🎓 AI Tutor: Smart Educational Summarizer",
    description="Paste long educational content and get a concise summary using AI."
)

# Launch the app
demo.launch()