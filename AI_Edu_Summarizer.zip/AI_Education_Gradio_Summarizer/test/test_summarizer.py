import unittest
from app.summarizer import summarize_text

class TestSummarizer(unittest.TestCase):
    def test_summary_not_empty(self):
        input_text = """Artificial Intelligence is the simulation of human intelligence in machines that are programmed to think like humans and mimic their actions."""
        summary = summarize_text(input_text)
        self.assertTrue(len(summary.strip()) > 0)

    def test_empty_input(self):
        self.assertEqual(summarize_text(" "), "No text provided.")

if __name__ == "__main__":
    unittest.main()