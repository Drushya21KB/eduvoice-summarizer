# app/config.py

MODEL_NAME = "sshleifer/distilbart-cnn-12-6"
MIN_LENGTH = 30
MAX_LENGTH = 130
