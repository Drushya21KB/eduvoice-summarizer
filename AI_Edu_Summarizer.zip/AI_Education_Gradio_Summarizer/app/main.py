# app/main.py

import gradio as gr
from app.summarizer import summarize_text
import pyttsx3
import speech_recognition as sr

# TTS engine
tts_engine = pyttsx3.init()

def summarize_and_speak(text):
    summary = summarize_text(text)
    tts_engine.say(summary)
    tts_engine.runAndWait()
    return summary

def speech_to_summary(audio):
    recognizer = sr.Recognizer()
    with sr.AudioFile(audio) as source:
        audio_data = recognizer.record(source)
        text = recognizer.recognize_google(audio_data)
    return summarize_and_speak(text)

with gr.Blocks(title="🎙️ AI Tutor: Voice Summarizer") as demo:
    gr.Markdown("# 🧠 AI Tutor: Summarizer with Voice Support\nSpeak or type educational content to get a summary and hear it aloud!")

    with gr.Row():
        with gr.Column():
            mic_input = gr.Audio(sources=["microphone"], type="filepath", label="🎤 Speak here")
            text_input = gr.Textbox(label="Or paste text here", lines=6, placeholder="Enter educational text...")

        with gr.Column():
            output_summary = gr.Textbox(label="📄 Summary", lines=6)
            tts_button = gr.Button("🔊 Read Summary Aloud")

    mic_input.change(fn=speech_to_summary, inputs=mic_input, outputs=output_summary)
    text_input.change(fn=summarize_and_speak, inputs=text_input, outputs=output_summary)
    tts_button.click(fn=summarize_and_speak, inputs=output_summary, outputs=output_summary)

demo.launch()
