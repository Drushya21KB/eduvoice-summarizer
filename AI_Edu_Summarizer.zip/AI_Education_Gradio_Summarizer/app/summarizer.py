# app/summarizer.py

from transformers import pipeline
from app.config import MODEL_NAME, MIN_LENGTH, MAX_LENGTH

summarizer_pipeline = pipeline("summarization", model=MODEL_NAME)

def summarize_text(text):
    summary = summarizer_pipeline(text, min_length=MIN_LENGTH, max_length=MAX_LENGTH, do_sample=False)
    return summary[0]['summary_text']

    try:
        # Truncate text to MAX_INPUT_LENGTH tokens
        text = text.strip()[:MAX_INPUT_LENGTH]

        # Run summarization
        result = summarizer(
            text,
            max_length=MAX_OUTPUT_LENGTH,
            min_length=30,
            do_sample=False
        )
        return result[0]['summary_text']
    
    except Exception as e:
        return f"❌ Error during summarization: {str(e)}"
